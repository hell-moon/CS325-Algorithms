# CS 325 Algorithms, HW 3: Dynamic Programming Shopping Algorithm
This shopping algorithm is just 0/1 knapsack problem, but with many "knapsacks" as family members.  

## Summary
The program reads the shopping spree giveaway criteria from "shopping.txt" and writes the optimal results to a "results.txt" file. The first line of the shopping.txt file is the number of test cases for the file.  Each test case has the number of items, followed by the price and weight of each item, on it's own line; followed by the number of family members that won, with each member's weight capacity on their own line.  

## Compilation and execution
To compile this C program, type in terminal with "shopping.c" in the current working directory: `gcc -g -o shopping shopping.c`.

This will compile the source code into a program named `shopping`. 

To execute, type in terminal: `./shopping`, and the program will read input as described above, from "shopping.txt" in the same directory, and print the optimal results for each test case in "shopping.txt" to a file named "results.txt". 