#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void error(const char *msg)
{
  perror(msg);
  exit(0);
} // Error function used for reporting issues

// returns the maximum of two integers
int max(int a, int b)
{
  if (a > b)
  {
    return a;
  }
  else
  {
    return b;
  }
}

// void printTable(int T[][], int N, int W)
// {
// 	int i, j;
// 	for (i = 0; i < N + 1; i++)
// 	{
// 		for (j = 0; j < W + 1; j++)
// 		{
// 			printf("%d ", T[i][j]);
// 			if (j == W)
// 			{
// 				printf("\n");
// 			}
// 		}
// 	}
// }

// dynamic programming algorithm for determining the maximum value for a 0/1 knapsack problem.  This function writes results to file pointer "results"
void knapSack(int val[], int weight[], int members[], int N, int W, int M, FILE* results)
{
  // make DP table, 6 rows x 25
  int T[N + 1][W + 1];
  // fill first row and column with 0
  int i, j, k;
  for (i = 0; i < N + 1; i++)
  {
    T[i][0] = 0;
  }
  for (j = 0; j < W + 1; j++)
  {
    T[0][j] = 0;
  }

  // build DP table
  // bottom-up approach, start by building up each item, and find maximum value for weights 0->(weight capacity of member)
  for (i = 1; i < N + 1; i++)
  {
    for (j = 1; j < W + 1; j++)
    {
      // If the weight capacity at this iteration can hold the weight of the item we are iterating, then we take the maximum value of either: 
      // 1) the solution for this weight if the current item is not included
      // 2) the value of the item if we include it, plus the solution for the remainder of the weight
      if (weight[i - 1] <= j)
      {
        T[i][j] = max(val[i - 1] + T[i - 1][j - weight[i - 1]], T[i - 1][j]);
      }
      // if the weight capacity at this iteration is not sufficient to include the weight of the current item, take the solution for the current weight capacity without this item (1 row above)
      else
      {
        T[i][j] = T[i - 1][j];
      }
    }
  }
  // printf("Total Price %d\n", T[N][W]);
  // for each member, list items they carry


  // backtrack through DP table for maximum weight of each member, to determine which items they carry for the optimal solution
  int total = 0;
  for (i = 0; i < M; i++)
  {
    int n = N;
    fprintf(results, "%d: ", i + 1);
    j = members[i];
    // keep running total of each member's optimal solution
    total += T[N][j];
    // while backtracing through table coordinates is still valid
    while (j > 0 && n > 0)
    {
      // starting at optimal solution for the member, T[n][j]
      // if the value at this cell is the same as the one above, then we did not include this item at row n
      if (T[n][j] == T[n - 1][j])
      {
        // go up a row to check if we used the previous item
        n--;
      }
      else
      {
        // we did use this item for the solution, print the item index
        fprintf(results, "%d ", n);
        // go up a row to check if we used the previous item
        n--;
        // since we used this item, subtract it's weight and see if we used any other items
        j = j - weight[n];
      }
    }
    fprintf(results, "\n");
  }
  fprintf(results, "Total Price %d\n\n", total);

  // printf("\n");
  // for (i = 0; i < N + 1; i++)
  // {
  //   for (j = 0; j < W + 1; j++)
  //   {
  //     printf("%d ", T[i][j]);
  //     if (j == W)
  //     {
  //       printf("\n");
  //     }
  //   }
  // }
}

int maxMembers(int members[], int M)
{
  int max = -1;
  int i = 0;
  for (i = 0; i < M; i++)
  {
    if (members[i] > max)
    {
      max = members[i];
    }
  }
  return max;
}



int main()
{
  // open file pointer for shopping.txt
  FILE *shopping = fopen("shopping.txt", "r");
  if (shopping == NULL)
  {
    error("Unable to open shopping.txt");
  }
  // create results.txt output file
  FILE *results = fopen("results.txt", "w");
  if (results == NULL)
  {
    error("Unable to open results.txt");
  }
  // iterators
  int i, j, k, l;

  // first line of shopping.txt is the number of test cases
  int charRead = -5;
  char buffer[100];
  char *lineptr = NULL;
  size_t n = 0;
  int TC = -5;

  // fscanf(shopping,"%[^\n]", buffer);
  // // printf("%s", buffer);
  // TC = atoi(buffer);  //number of test cases

  // // for each test case, get and parse the items into value and weight arrays, get members and parse into array

  getline(&lineptr, &n, shopping);
  TC = atoi(lineptr);

  // ##########FOR EACH TEST CASE
  for (l = 0; l < TC; l++)
  {
    fprintf(results, "\nTest Case: %d\n", l + 1);
    getline(&lineptr, &n, shopping);
    int N = atoi(lineptr);
    // printf("%d", N);  //N gets parsed correctly
    int val[100];    //store prices for this test case
    int weight[100]; //store weights for this test case
    for (i = 0; i < N; i++)
    {
      // for each N lines, two values, a price and weight
      char *token;
      getline(&lineptr, &n, shopping);
      token = strtok(lineptr, " ");
      int price = atoi(token);
      // printf("price: %d\n", price);
      val[i] = price;
      token = strtok(NULL, "");
      int w = atoi(token);
      // printf("weight: %d\n", w);
      weight[i] = w;
    }

    // printf("%d\n", val[0]);
    // printf("%d\n", weight[0]);
    //   printf("%d\n", val[1]);
    // printf("%d\n", weight[1]);

    // get number of family members
    getline(&lineptr, &n, shopping);
    int M = atoi(lineptr);
    int members[30];
    // printf("members: %d", M);
    for (j = 0; j < M; j++)
    {
      getline(&lineptr, &n, shopping);
      int WC = atoi(lineptr);
      members[j] = WC;
      // printf("%d ", members[j]);
    }

  //   // print value and weight and member arrays
  //   printf("Values: ");
  //   for (k = 0; k < N; k++)
  //   {
  //     printf("%d ", val[k]);
  //   }
  //   printf("\n");

  //   printf("Weights: ");
  //   for (k = 0; k < N; k++)
  //   {
  //     printf("%d ", weight[k]);
  //   }
  //   printf("\n");

  //   printf("Members: ");
  //   for (k = 0; k < M; k++)
  //   {
  //     printf("%d ", members[k]);
  //   }
  //   printf("\n");


  // create one large DP table for all members, using the largest weight capacity of the members
  int W = maxMembers(members, M);
  knapSack(val, weight, members, N, W, M, results);
  }
  
  free(lineptr);
  fclose(shopping);
  fclose(results);
  return 0;
}